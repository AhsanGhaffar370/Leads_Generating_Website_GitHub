<!--#####################################CDN LINKS OF BOOTSTRAP##########################################-->
 <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script> 

<!--font awesome for images icons -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.2/css/all.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<!--#####################################CDN LINKS OF BOOTSTRAP##########################################-->


<!--#######################################################################################
<base href="https://affordableattorneyleads.com/">
-->
<link rel="stylesheet" href="../style sheet/css1_new.css?v=2">

<link rel="stylesheet" href="admin_style.css?v=2" />
<!--to make it responsive for mobile-->
<meta charset="utf-8" />
<meta name="viewport" content="width=device-wdth, initial-scale=1.0" />
<!--#######################################################################################-->