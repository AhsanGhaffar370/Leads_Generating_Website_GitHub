<?php 
   
$con = mysqli_connect("localhost","u728873214_lead","123456","u728873214_leads_generate");
if (!$con)
  {
  die('Could not connect: ' . mysqli_connect_error());
  }
?>