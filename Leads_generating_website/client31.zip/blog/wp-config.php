<?php
define('WP_CACHE', true);
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'u728873214_gvF62' );

/** MySQL database username */
define( 'DB_USER', 'u728873214_L0VjG' );

/** MySQL database password */
define( 'DB_PASSWORD', '56ByRNDqwq' );

/** MySQL hostname */
define( 'DB_HOST', 'mysql' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',          '7/U;N`9eDS`!>i31&H?_(28S6XHy$;l8^sYx$GyR6&S4,5|f]GQV!XoQ`}sllQwS' );
define( 'SECURE_AUTH_KEY',   'kpt)aAd)4H{7X?hMgt..|{eK*>_hIpWj.@Y>km.v{(F#zub]jP>az56QJ(+dk2.n' );
define( 'LOGGED_IN_KEY',     '1t=ny8v8tffk~yJo)bZ*tY500EkO]y}z)3Zrv1D_~K10H5DBF&}1ms1&2q#=%m7E' );
define( 'NONCE_KEY',         'Blc/{0E%6YMD}p@tl(H^PH!c}M&Lh~+)Fi.7viV];[^Jkpr6UZaFN)(6w(z%TRYv' );
define( 'AUTH_SALT',         'Bz_[b)Ec[e,o!<Mpr#Q`mE.I294SGQ?u 2KzXmXEv.L@jZ)mUNc5DZSD6][oQ[4I' );
define( 'SECURE_AUTH_SALT',  '+`<}9m8C7c(RJPpFI5!&b$t9&2+8/pXxfrrh~984DwU6^K7#vMC);NB-TK{vBX]W' );
define( 'LOGGED_IN_SALT',    'C^hLQ] &^cpA/gG)LJe6FPfj.4U@eo.h7NnHWvS$JrThdy]=[Svx/{;xt#w1N[s;' );
define( 'NONCE_SALT',        'FItizg>MA,)AGSdBbk7:AXy+]/0%1cguE%Q:F426*kNmvt5rb:TH&}3%-H=F*)G6' );
define( 'WP_CACHE_KEY_SALT', '&&(kiL5*@i*SrW =GQ3;]j)Pw5%lefr-jE*1EPs;MDR=8A=JK$RqJC+bu8&bp|.F' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
